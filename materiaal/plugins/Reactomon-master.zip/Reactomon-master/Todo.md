HTML - Structuur van website
1. 1x Basisstructuur PokemonCard maken V
2. 1x CounterCard basisstructuur maken V

CSS - Styling van de website
1. PokemonCard stylen v
1a. betere structuur van het kaartje v
1b. header stylen v
1c. section stylen v
1d. footer stylen v
1e. individuele elementen in 1b 1c end 1d te stylen v
2. CounterCard V
2a. de sectie stylen v
2b. het nummer stylen v

Layout
1. 4 kaartjes met ieder een eigen pokemon v
2. 4 kaartjes zoals op het ontwerp v
3. countercard zoals op het ontwerp v

JS(X) - Interactie van de website
1. PokemonCard maken
1a PokemonCard omzetten naar class v
1b Button werkend maken v
1c Moeten kunnen vangen
1d Moeten maar één keer kunnen vangen
  1d1 catch button klikken v
  1d2 bijhouden of pokemon gevangen kan worden v
  1d3 als pokemon dood is niet vangen v
  1d4 zo niet, pokemon op basis van damage vangen v

2. CounterCard V

Features

Code Refactoren
